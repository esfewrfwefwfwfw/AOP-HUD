local postal = nil
local streetName = ""
local crossingRoad = ""
local aop = "San Andreas" -- default
local compassDirs = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"}
local discordLink = "discord.gg/YourServer" -- ✨ Your Discord invite here

-- Rainbow colors
local r, g, b = 255, 0, 0
local step = 1

-- Wait until nearest-postal resource is started
CreateThread(function()
    while GetResourceState('nearest-postal') ~= 'started' do
        Wait(100)
    end

    -- Disable any UI from nearest-postal if it has such functionality (custom override)
    if exports['nearest-postal'] then
        -- Replace this with the actual function or convar if nearest-postal has an option
        -- exports['nearest-postal']:hideUI() -- Example, check if such a function exists.
    end
end)

function DrawTextHUD(x, y, scale, text, r, g, b, a)
    SetTextFont(4)
    SetTextProportional(1)
    SetTextScale(scale, scale)
    SetTextColour(r, g, b, a)
    SetTextDropShadow(0, 0, 0, 0, 255)
    SetTextEdge(2, 0, 0, 0, 255)
    SetTextOutline()
    SetTextEntry("STRING")
    AddTextComponentString(text)
    DrawText(x, y)
end

function getCompassHeading()
    local heading = GetEntityHeading(PlayerPedId())
    local dir = math.floor((heading + 22.5) / 45.0)
    return compassDirs[(dir % 8) + 1]
end

-- Rainbow color updater
CreateThread(function()
    while true do
        Wait(10)
        if r == 255 and g < 255 and b == 0 then
            g = g + step
        elseif g == 255 and r > 0 and b == 0 then
            r = r - step
        elseif g == 255 and b < 255 and r == 0 then
            b = b + step
        elseif b == 255 and g > 0 and r == 0 then
            g = g - step
        elseif b == 255 and r < 255 and g == 0 then
            r = r + step
        elseif r == 255 and b > 0 and g == 0 then
            b = b - step
        end
    end
end)

-- HUD Display
CreateThread(function()
    while true do
        local ped = PlayerPedId()
        local coords = GetEntityCoords(ped)

        -- Street names
        local street1, street2 = GetStreetNameAtCoord(coords.x, coords.y, coords.z)
        streetName = GetStreetNameFromHashKey(street1)
        crossingRoad = GetStreetNameFromHashKey(street2)

        -- Nearest postal (debugging)
        if GetResourceState('nearest-postal') == 'started' then
            postal = exports['nearest-postal']:getPostal()
            if postal == nil or postal == "" then
                postal = "Error: No Postal Found"
            end
        else
            postal = "Error: Postal Resource Not Started"
        end

        -- Compass
        local compass = getCompassHeading()

        -- Move the HUD near the minimap (Bottom left)
        local startX = 0.18 -- Move right to be near minimap
        local startY = 0.80 -- Lower to bottom

        -- Draw the HUD
        DrawTextHUD(startX, startY, 0.45, string.format("~w~Postal: ~s~%s", postal), r, g, b, 255)
        DrawTextHUD(startX, startY + 0.03, 0.45, string.format("~w~Location: ~s~%s / %s", streetName, crossingRoad), r, g, b, 255)
        DrawTextHUD(startX, startY + 0.06, 0.45, string.format("~w~Compass: ~s~%s", compass), r, g, b, 255)
        DrawTextHUD(startX, startY + 0.09, 0.45, string.format("~w~AOP: ~s~%s", aop), r, g, b, 255)

        -- Draw Discord Link (NEW!)
        DrawTextHUD(startX, startY + 0.12, 0.45, string.format("~w~Discord: ~s~%s", discordLink), r, g, b, 255)

        Wait(1)
    end
end)

-- Function to check if player has permission (group.admin aop.change)
function hasSetAOPPermission(player)
    return IsPlayerAceAllowed(player, "group.admin aop.change")
end

-- /setaop command
RegisterCommand('setaop', function(source, args)
    local player = source

    -- Check if player has the "group.admin aop.change" permission
    if not hasSetAOPPermission(player) then
        TriggerEvent('chat:addMessage', { args = { '^1Error:', 'You do not have permission to set the AOP.' }})
        return
    end

    -- Check if arguments are provided for AOP
    if #args == 0 then
        TriggerEvent('chat:addMessage', { args = { '^1Usage:', '/setaop [AOP Name]' }})
        return
    end

    -- Set the new AOP
    aop = table.concat(args, " ")
    TriggerEvent('chat:addMessage', { args = { '^2AOP Set To:', aop }})
end)
